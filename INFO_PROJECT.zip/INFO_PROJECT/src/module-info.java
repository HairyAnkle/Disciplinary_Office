/**
 * 
 */
/**
 * 
 */
module INFO_PROJECT {
	requires java.desktop;
	requires java.swing.drawer;
	requires java.sql;
}